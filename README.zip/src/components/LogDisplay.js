import React, { useEffect, useState } from 'react';
import SockJS from 'sockjs-client';
import { over } from 'stompjs';

const LogDisplay = () => {
    const [logs, setLogs] = useState([]);
    const socketUrl = 'http://localhost:8080/websocket';
    let stompClient;

    useEffect(() => {
        const connectWebSocket = () => {
            const socket = new SockJS(socketUrl);
            stompClient = over(socket);
            stompClient.connect({}, () => {
                stompClient.subscribe('/topic/updates', (message) => {
                    setLogs((prevLogs) => [...preLogs, message.body]);
                });
            });
        };

        connectWebSocket();
        return () => stompClient?.disconnect();
    }, []);

    return (
        <div >
            <h3>Logs</h3>
            <ul >
                {logs.map((log, index) => (
                    <li key={index}>{log}</li>
                ))}
            </ul>
        </div>        
    );
};

export default LogDisplay;